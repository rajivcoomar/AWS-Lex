
var aws = require('aws-sdk');
var db = new aws.DynamoDB({
  region: 'eu-west-2'
});



exports.handler = async (event) => {
 
    console.log(event.inputTranscript);
    
    var upiID = event.inputTranscript;
    
    let regex = new RegExp(/^[\w\.\-_]{3,}@[a-zA-Z]{3,}/);
    var found = regex.test(upiID);
 			console.log(found);
 			
 			var resultMatch = "";
 			if(found == false)
 			{
 			  resultMatch = "Failed";
 			}
 			else
 			{
 				resultMatch = "Fulfilled";
 			}
    
   return {
    "sessionState": {
     "dialogAction": {   
               "type": "Close"
                 },
          		    "intent": {
          		      "name": "Welcome",
          				    "state": resultMatch
          		       }
          	   	  }
              }
          
};
